package com.example.missionk3.Fragments;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.missionk3.CommonUtils.CommonUtils;
import com.example.missionk3.Adapters.AudioGalleryAdapter;
import com.example.missionk3.R;

public class AudioGallery_Fragment extends Fragment {
    AudioGalleryAdapter audioGalleryAdapter;
    RecyclerView recycler_audio;

    View view;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view= inflater.inflate(R.layout.fragment_audio__gallery, container, false);
        recycler_audio=view.findViewById(R.id.recycler_audio);
        audioGalleryAdapter = new AudioGalleryAdapter(getActivity());
        recycler_audio.setLayoutManager(CommonUtils.verticalRecycleHandle(getActivity()));
        recycler_audio.setAdapter(audioGalleryAdapter);



        return view;
    }
}