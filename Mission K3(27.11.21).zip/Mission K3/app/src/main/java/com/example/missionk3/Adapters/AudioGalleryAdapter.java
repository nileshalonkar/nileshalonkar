package com.example.missionk3.Adapters;


import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageSwitcher;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.missionk3.R;


public class AudioGalleryAdapter extends RecyclerView.Adapter<AudioGalleryAdapter.MyViewholder> {

    //  THIS ADAPTER IS LIKE THE FEED OF INSTAGRAM  //


// FOR ANY TYPE OF TEXT....

    Context context;
    String[] txt_speech_title = {"Motivational speech", "Mind Divert speech", "Peace speech", "Shrpen speech"
    ,"Mind Divert speech","Peace speech","Motivational speech","Sharpen speech","Mind Divert speech","Yoga speech"
            ,"Health Related Speech","Sharpen Sppech","Peace Speech","motivational Speech","Yoga Speech"
    };
//    String[] location = {"Poland", "Thailand", "Brazil"};
//    String[] caption= {"Hey Buddy I am joining the new job in Accenture as a junior Backend Developer.",
//            "Hey Buddy I am joining the new job in Accenture as a junior Backend Developer.",
//            "Hey Buddy I am joining the new job in Accenture as a junior Backend Developer."};


// FOR ANY TYPE OF IMAGES...

//    int[] user_image = {R.drawable.profile, R.drawable.profile_two, R.drawable.profile_three};
//    int[] user_post = {R.drawable.profile, R.drawable.profile_two, R.drawable.profile_three};
//

    public AudioGalleryAdapter(Context ct) {
        context = ct;


    }

    @NonNull
    @Override
    public MyViewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.audio_view, parent, false);
        return new MyViewholder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewholder holder, int position) {

        holder.txt_speech_title.setText(txt_speech_title[position]);
//        holder.location.setText(location[position]);
//        holder.caption.setText(caption[position]);
//        holder.user_image.setImageResource(user_image[position]);
//        holder.user_post.setImageResource(user_post[position]);
    }

    @Override
    public int getItemCount() {
        return txt_speech_title.length;
    }

    public static class MyViewholder extends RecyclerView.ViewHolder {

        //        public ImageSwitcher candidate_post;
        TextView txt_speech_title;
        RelativeLayout audio_relative;
//        ImageView user_image, user_post;

        public MyViewholder(@NonNull View itemView) {
            super(itemView);

            audio_relative = itemView.findViewById(R.id.audio_relative);
            txt_speech_title = itemView.findViewById(R.id.txt_speech_title);
//            caption=itemView.findViewById(R.id.caption);
//            location = itemView.findViewById(R.id.location);
//            user_image = itemView.findViewById(R.id.user_image);
//            user_post = itemView.findViewById(R.id.user_post);

        }
    }
}
