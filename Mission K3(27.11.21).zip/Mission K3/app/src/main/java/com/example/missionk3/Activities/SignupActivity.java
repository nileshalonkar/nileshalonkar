package com.example.missionk3.Activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.missionk3.R;

import de.hdodenhof.circleimageview.CircleImageView;

public class SignupActivity extends AppCompatActivity {

    Button btn_submit;

    RelativeLayout sugnup_relative;

    TextView txt_signin;

    EditText enter_email, enter_password, enter_confirm_password, enter_name;

    CircleImageView user_dp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);


        //TODO--ALL ID'S

        sugnup_relative = findViewById(R.id.sugnup_relative);
        btn_submit = findViewById(R.id.btn_submit);
        txt_signin = findViewById(R.id.txt_signin);
        enter_email = findViewById(R.id.enter_email);
        enter_name = findViewById(R.id.enter_name);
        enter_password = findViewById(R.id.enter_password);
        enter_confirm_password = findViewById(R.id.enter_confirm_password);
        user_dp = findViewById(R.id.user_dp);


        //TODO---CLICK LISTENER

        btn_submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SignupActivity.this, OTPActivity.class);
                startActivity(intent);
            }
        });

        sugnup_relative.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SignupActivity.this, SigninActivity.class);
                startActivity(intent);
            }
        });

        btn_submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = enter_email.getText().toString().trim();

                String password = enter_password.getText().toString().trim();
                String confirmPassword = enter_confirm_password.getText().toString().trim();

                String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";

                if (enter_name.getText().toString().equals("")) {
                    Toast.makeText(SignupActivity.this, "Please enter your name", Toast.LENGTH_SHORT).show();

                } else if (enter_email.getText().toString().equals("")) {
                    Toast.makeText(SignupActivity.this, "Please enter your email", Toast.LENGTH_SHORT).show();

                } else if (!email.matches(emailPattern)) {
                    Toast.makeText(SignupActivity.this, "Please enter valid email address.", Toast.LENGTH_SHORT).show();

                } else if (enter_password.getText().toString().equals("")) {
                    Toast.makeText(SignupActivity.this, "Please enter your password", Toast.LENGTH_SHORT).show();

                } else if (enter_confirm_password.getText().toString().equals("")) {
                    Toast.makeText(SignupActivity.this, "Please confirm your password", Toast.LENGTH_SHORT).show();

                } else if (!password.equals(confirmPassword)) {
                    Toast.makeText(SignupActivity.this, "Confirm password is not correct", Toast.LENGTH_SHORT).show();

                } else {
                    Intent intent = new Intent(SignupActivity.this, OTPActivity.class);
                    startActivity(intent);
                }
            }
        });


    }
}