package com.example.missionk3.Adapters;


import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageSwitcher;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.missionk3.R;


public class HomeAdapter extends RecyclerView.Adapter<HomeAdapter.MyViewholder> {

    //  THIS ADAPTER IS LIKE THE FEED OF INSTAGRAM  //


// FOR ANY TYPE OF TEXT....

    Context context;
    String[] name_user = {"Johny Diven", "Elbert", "Andrew"};
    String[] location = {"Poland", "Thailand", "Brazil"};
    String[] caption= {"Hey Buddy I am joining the new job in Accenture as a junior Backend Developer.",
            "Hey Buddy I am joining the new job in Accenture as a junior Backend Developer.",
            "Hey Buddy I am joining the new job in Accenture as a junior Backend Developer."};


// FOR ANY TYPE OF IMAGES...

    int[] user_image = {R.drawable.profile, R.drawable.profile_two, R.drawable.profile_three};
    int[] user_post = {R.drawable.env_four, R.drawable.env_second, R.drawable.env_three};


    public HomeAdapter(Context ct) {
        context = ct;


    }

    @NonNull
    @Override
    public MyViewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.home_view, parent, false);
        return new MyViewholder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewholder holder, int position) {

        holder.name_user.setText(name_user[position]);
//        holder.location.setText(location[position]);
        holder.caption.setText(caption[position]);
        holder.user_image.setImageResource(user_image[position]);
        holder.user_post.setImageResource(user_post[position]);
    }

    @Override
    public int getItemCount() {
        return name_user.length;
    }

    public class MyViewholder extends RecyclerView.ViewHolder {

        //        public ImageSwitcher candidate_post;
        TextView name_user, location,caption;
        RelativeLayout postrelative;
        ImageView user_image, user_post;

        public MyViewholder(@NonNull View itemView) {
            super(itemView);

            postrelative = itemView.findViewById(R.id.postrelative);
            name_user = itemView.findViewById(R.id.name_user);
            caption=itemView.findViewById(R.id.caption);
//            location = itemView.findViewById(R.id.location);
            user_image = itemView.findViewById(R.id.user_image);
            user_post = itemView.findViewById(R.id.user_post);

        }
    }
}
