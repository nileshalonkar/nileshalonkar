package com.example.missionk3.Adapters;


import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageSwitcher;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.missionk3.R;


public class VideoAdapter extends RecyclerView.Adapter<VideoAdapter.MyViewholder> {

    //  THIS ADAPTER IS LIKE THE FEED OF INSTAGRAM  //


// FOR ANY TYPE OF TEXT....

    Context context;
    String[] video_title = {"Motivational Speech",
            "Peace Speech",
            "Mind Sharpen",
            "Yoga Speech",
            "Health Related Speech"};


    int[] video_image = {R.drawable.envi_first,
            R.drawable.envi_sec,
            R.drawable.envi_three,
            R.drawable.envi_four,
            R.drawable.envi_five};
//    int[] user_post = {R.drawable.profile, R.drawable.profile_two, R.drawable.profile_three};
//

    public VideoAdapter(Context ct) {
        context = ct;


    }

    @NonNull
    @Override
    public MyViewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.video_view, parent, false);
        return new MyViewholder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewholder holder, int position) {

        holder.video_title.setText(video_title[position]);
//        holder.location.setText(location[position]);
//        holder.caption.setText(caption[position]);
        holder.video_image.setImageResource(video_image[position]);
//        holder.user_post.setImageResource(user_post[position]);
    }

    @Override
    public int getItemCount() {
        return video_title.length;
    }

    public class MyViewholder extends RecyclerView.ViewHolder {

        //        public ImageSwitcher candidate_post;
        TextView video_title;
        LinearLayout video_linear;
        ImageView video_image, user_post;

        public MyViewholder(@NonNull View itemView) {
            super(itemView);

            video_linear = itemView.findViewById(R.id.video_linear);
            video_title = itemView.findViewById(R.id.video_title);
//            caption=itemView.findViewById(R.id.caption);
//            location = itemView.findViewById(R.id.location);
            video_image = itemView.findViewById(R.id.video_image);
//            user_post = itemView.findViewById(R.id.user_post);

        }
    }
}
