package com.example.missionk3.Fragments;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.missionk3.CommonUtils.CommonUtils;
import com.example.missionk3.Adapters.VideoAdapter;
import com.example.missionk3.R;

public class VideoGallery_Fragment extends Fragment {
    RecyclerView video_gallery_recycler;
    VideoAdapter videoAdapter;



    View view;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view= inflater.inflate(R.layout.fragment_video__gallery, container, false);
        video_gallery_recycler=view.findViewById(R.id.video_gallery_recycler);

        videoAdapter = new VideoAdapter(getActivity());
        video_gallery_recycler.setLayoutManager(CommonUtils.verticalRecycleHandle(getActivity()));
        video_gallery_recycler.setAdapter(videoAdapter);



        return view;
    }
}